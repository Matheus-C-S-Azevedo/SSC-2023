#  WWDC/SSC 2023 - TUPÃ
## By: Matheus Costa

## Credits:

    All sound, assets, illustrations, 3D models, and textures were made by me. 


## Especifications

The project uses augmented reality and has audio and haptic feedback, so for a better experience, use an iPad in portrait mode and iPods to hear the sound.

##Objective: 

This project aims to teach the culture of northern Brazil to people who don't know it. In this game, you must use augmented reality to search for the Amazonian folklore monsters. When you find them, you must touch them to collect them. As soon as you collect them, the story of each monster will appear.

Enjoy, and I hope that this project will inspire you to learn more about Brazilian culture.

fondly, Matheus.
