//
//  AppDelegate.swift
//  RealityHitTest
//
//  Created by Matheus Costa on 08/04/23.
//

import SwiftUI

@main
struct MyApp: App {
    
    var body: some Scene {
        
        WindowGroup {
            HomeView()
        }
    }
}
