//
//  StoryView.swift
//  Swift_Student_Challenge-2023
//
//  Created by Matheus Costa on 13/04/23.
//

import SwiftUI

struct StoryView: View {
    
    
    var body: some View {
        GeometryReader{ sc in
            ZStack{
                Image("RiverBackground")
                    .resizable()
                    .scaledToFill()
                
                VStack(alignment: .center){
                    
                    Image("Paje")
                        .resizable()
                        .scaledToFill()
                        .frame(width: sc.size.width * 0.394, height: sc.size.height * 0.208)
                        .padding(.bottom, sc.size.height * 0.100)
                        .padding(.top, sc.size.height * 0.100)
                    
                    Text(Texts.storyPlot)
                        .font(.system(size: 25, weight: .regular, design: .rounded))
                        .lineSpacing(20)
                        .foregroundColor(Color("FontColor"))
                        .multilineTextAlignment(.center)
                        .padding(.horizontal, sc.size.width * 0.162)
                        .padding(.bottom, sc.size.height * 0.041)
                    
                    Text(Texts.AdvText)
                        .font(.system(size: 25, weight: .bold, design: .rounded))
                        .foregroundColor(Color("FontColor"))
                        .multilineTextAlignment(.center)
                        .frame(width: sc.size.width * 0.797, height: sc.size.height * 0.065)
                    
//                    Spacer()
//                        .frame(height: sc.size.height * 0.070)
                    
                    NavigationLink(destination: ContentView()) {
                        Image("GoFindButton")
                            .resizable()
                            .scaledToFit()
                    }
                    .frame(width: sc.size.width * 0.538, height: sc.size.height * 0.085)
                    //                    .padding(.bottom, sc.size.height * 0.041)
                    Spacer()
                }
            }
            .ignoresSafeArea()
            .navigationBarBackButtonHidden()
            .navigationBarHidden(true)
        }
    }
}
