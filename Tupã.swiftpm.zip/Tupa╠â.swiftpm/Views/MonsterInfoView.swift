//
//  MonsterInfoView.swift
//  Swift_Student_Challenge-2023
//
//  Created by Matheus Costa on 13/04/23.
//

import SwiftUI

struct MonsterInfoView: View {
    
    @StateObject var controller = MySingleton.instance
    @Binding var show: Bool
    var monster: MonsterInfo
    
    var body: some View {
        GeometryReader{ sc in
            VStack(){
                Spacer()
                ZStack(alignment: .center){
                    // BackGround.
                    Image("PopUpBackGround")
                        .resizable()
                        .scaledToFill()
                        .cornerRadius(20, corners: [.topLeft, .topRight])
                    
                    VStack(alignment: .center, spacing: 15){
                        
                        // Header: Label + Xbutton.
                        HStack{
                            Spacer()
                            Image(monster.labelPic)
                                .resizable()
                                .frame(width: sc.size.width * 0.617, height: sc.size.height * 0.089)
                                .scaledToFill()
                                .padding(.trailing, sc.size.width * 0.048)
                            
                            if  controller.MonstersFinded < 3 {
                                
                                Button {
                                    withAnimation {
                                        show.toggle()
                                    }
                                } label: {
                                    Image("CloseButton")
                                        .resizable()
                                        .scaledToFit()
                                }
                                .frame(width: sc.size.width * 0.094, height: sc.size.height * 0.043)
                                .padding(.trailing, sc.size.width * 0.041)
                                
                            } else {
                                
                                NavigationLink(destination: FinalView()) {
                                    Image("CloseButton")
                                        .resizable()
                                        .scaledToFit()
                                }
                                .frame(width: sc.size.width * 0.094, height: sc.size.height * 0.043)
                                .padding(.trailing, sc.size.width * 0.041)
                                
                            }
                        }
                        .padding(.top, sc.size.height * 0.02)
                        
                        Image(monster.iconPic)
                            .resizable()
                            .frame(width: sc.size.width * 0.200, height: sc.size.height * 0.136)
                            .scaledToFit()
                            .padding(.horizontal, sc.size.width * 0.041)
                            .padding(.vertical, sc.size.width * 0.07)
                        Text(monster.Text)
                            .font(.system(size: 25, weight: .regular, design: .rounded))
                            .lineSpacing(25)
                            .foregroundColor(Color("FontColor"))
                            .multilineTextAlignment(. center)
                        //                            .frame(width: sc.size.width * 0.256, height: sc.size.height * 0.118)
                            .padding(.horizontal, sc.size.width * 0.162)
                        Spacer()
                        
                    }
                }
                .ignoresSafeArea()
                .frame(width: sc.size.width, height: sc.size.height * 0.5)
                .background(.clear)
            }
        }
    }
}
