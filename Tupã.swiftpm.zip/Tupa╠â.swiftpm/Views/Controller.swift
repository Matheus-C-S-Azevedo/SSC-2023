//
//  ContentViewModel.swift
//  RealityHitTest
//
//  Created by Matheus Costa on 08/04/23.
//

import Foundation
import SwiftUI

class MySingleton: ObservableObject{
    static let instance = MySingleton()
    
    @Published var MonstersFinded: Int = 0
    @Published var DolphinIsEnabled: Bool = false
    @Published var CurupiraIsEnabled: Bool = false
    @Published var MatintaIsEnabled: Bool = false
    @Published var showingBottonSheet = false
    @Published var viewType:ViewType = .info
    @Published var selectedMonster: MonsterInfo?
    
    let DolphinInfo:MonsterInfo = MonsterInfo(labelPic: "BotoLbl", iconPic: "BotoIcon", Text: Texts.DolphinDescription)
    let CurupiraInfo:MonsterInfo = MonsterInfo(labelPic: "CurupiraLbl",iconPic:"CurupiraIcon",Text: Texts.CurupiraDescription)
    let MatintaInfo:MonsterInfo = MonsterInfo(labelPic: "MatintaLbl", iconPic: "MatintaIcon", Text: Texts.MatintaDescription)
    
    private init(){}
}

