//
//  WorldARView.swift
//  RealityHitTest
//
//  Created by Matheus Costa on 08/04/23.
//

import Foundation
import RealityKit
import ARKit
import Combine
import SwiftUI

class WoldARView: ARView, ARSessionDelegate {
    var soundControler = SoundContrller.instance
}


extension WoldARView {
    // Add UITapRecognizer
    func setupGesture(){
        self.addGestureRecognizer(
            UITapGestureRecognizer(
                target: self,
                action: #selector(self.handleTap(_:))
            )
        )
    }
    
    func simpleSuccess() {
        let generator = UIImpactFeedbackGenerator(style: .soft)
        generator.impactOccurred()
    }
    
    @objc func handleTap(_ sender: UITapGestureRecognizer? = nil){
        
        var subscription: AnyCancellable?
        
        guard subscription == nil else { return }
        guard let tapLocation = sender?.location(in: self) else {return}
        guard let hitEntity = self.entity(at: tapLocation) else {return}
        
        MySingleton.instance.MonstersFinded += 1
        simpleSuccess()
        soundControler.playFoundSound()
        
        var rotationTransform = hitEntity.transform
        rotationTransform.rotation = simd_quatf(angle: .pi, axis: [0, 1, 0])
        rotationTransform.scale = simd_float3(repeating: 2)
        rotationTransform.translation = [hitEntity.position.x, 0.13, hitEntity.position.z]
        
        _ = hitEntity.move(to: rotationTransform, relativeTo: hitEntity.parent, duration: 1.7)
        
        // Execute this when finish  transform
        subscription = scene.publisher(for: AnimationEvents.PlaybackCompleted.self, on: hitEntity).sink(receiveValue: { [weak self] _ in
            
            hitEntity.removeFromParent()
            
            switch hitEntity.name {
                
            case "Dolphin":

                self?.soundControler.startBirdMusic()
                MySingleton.instance.DolphinIsEnabled = true
                MySingleton.instance.viewType = .monsterInfo
                MySingleton.instance.selectedMonster = MySingleton.instance.DolphinInfo
                withAnimation {
                    MySingleton.instance.showingBottonSheet.toggle()
                }
                
            case "Curupira":
                
                self?.soundControler.startBirdMusic()
                MySingleton.instance.CurupiraIsEnabled = true
                MySingleton.instance.viewType = .monsterInfo
                MySingleton.instance.selectedMonster = MySingleton.instance.CurupiraInfo
                withAnimation {
                    MySingleton.instance.showingBottonSheet.toggle()
                }
                
            case "Matinta":
                
                self?.soundControler.startBirdMusic()
                MySingleton.instance.MatintaIsEnabled = true
                MySingleton.instance.viewType = .monsterInfo
                MySingleton.instance.selectedMonster = MySingleton.instance.MatintaInfo
                withAnimation {
                    MySingleton.instance.showingBottonSheet.toggle()
                }
                
            default: break
            }
            
            // Set subscription to nil so another animation can start
            subscription = nil
        })
    }
}
