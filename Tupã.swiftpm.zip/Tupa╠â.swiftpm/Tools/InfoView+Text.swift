//
//  TextModel.swift
//  Swift_Student_Challenge-2023
//
//  Created by Matheus Costa on 13/04/23.
//

import Foundation

extension InfoView{
    enum Texts{
        static let DolphinName = "Pink Dolphin"
        static let DolphinTitle = "The river helper"
        
        static let CurupiraName = "Curupira"
        static let CurupiraTitle = "The forest protector"
        
        static let MatintaName = "Matinta Pereira"
        static let MatintaTitle = "The witch bird"
    }
}
