//
//  File.swift
//  
//
//  Created by Matheus Costa on 13/04/23.
//

import Foundation

extension StoryView{
    enum Texts{
        static let storyPlot = "You are in a native Brazilian tribe located in the dense Amazon Rainforest in Brazil. The culture and folklore of this tribe have many myths and tales about monsters and creatures that live near there.\n\nThe Pajé (ancient healer) is worried about the safety of this tribe and has called you, a brave adventurer, to search and find three local tale's monsters who are known to help this tribe in times of need."
        
        static let AdvText = "When you find the monsters, tap on them to collect them"
    }
}
