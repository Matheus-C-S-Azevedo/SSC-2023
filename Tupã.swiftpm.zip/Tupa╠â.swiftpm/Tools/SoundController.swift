//
//  File.swift
//  
//
//  Created by Matheus Costa on 18/04/23.
//

import Foundation
import AVFoundation

class SoundContrller {
    static let instance = SoundContrller()
    
    var audioPlayer: AVAudioPlayer?
    
    private init() {}
    
    func startBirdMusic(){
        guard let path = Bundle.main.path(forResource: "BirdSound", ofType: "mp3") else {return}
        let url = URL(fileURLWithPath: path)
        do {
            audioPlayer = try AVAudioPlayer(contentsOf: url)
            audioPlayer?.numberOfLoops = -1
            audioPlayer?.play()
        } catch {
            print("error with Audio Player")
        }
    }
    
    func playFoundSound(){
        guard let path = Bundle.main.path(forResource: "SucessSound", ofType: "mp3") else {return}
        let url = URL(fileURLWithPath: path)
        do {
            audioPlayer = try AVAudioPlayer(contentsOf: url)
            audioPlayer?.numberOfLoops = 0
            audioPlayer?.play()
        } catch {
            print("error with Audio Player")
        }
    }
}
