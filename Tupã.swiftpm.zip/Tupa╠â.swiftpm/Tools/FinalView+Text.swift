//
//  File.swift
//  
//
//  Created by Matheus Costa on 13/04/23.
//

import Foundation

extension FinalView{
    enum Texts{
        static let finalText = "With the three monsters at your side, you return to the tribe and present each of them to the Pajé (ancient healer). The tribe is grateful for your help, and the monsters set to work to help the community.\n\nThis journey can be a great opportunity for you to meet other tales of Brazilian folklore. Brazil is rich in myths and tales, if you have the opportunity, be sure to explore Brazilian folklore and its fascinating tales."
    }
}
