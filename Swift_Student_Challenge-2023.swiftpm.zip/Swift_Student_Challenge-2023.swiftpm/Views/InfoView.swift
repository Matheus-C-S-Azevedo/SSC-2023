//
//  InfoView.swift
//  Swift_Student_Challenge-2023
//
//  Created by Matheus Costa on 13/04/23.
//

import SwiftUI

struct InfoView: View {
    @Binding var show: Bool
    
    var body: some View {
        GeometryReader{ sc in
            VStack(){
                Spacer()
                ZStack(alignment: .center){
                    // BackGround.
                    Image("PopUpBackGround")
                        .resizable()
                        .scaledToFill()
                        .cornerRadius(20, corners: [.topLeft, .topRight])
                    
                    VStack(alignment: .leading, spacing: 20){
                        
                        // Header: Label + Xbutton.
                        HStack{
                            Spacer()
                            Image("WhatToFindLbl")
                                .resizable()
                                .frame(width: sc.size.width * 0.617, height: sc.size.height * 0.069)
                                .scaledToFill()
                                .padding(.trailing, sc.size.width * 0.048)
                            Button {
                                withAnimation {
                                    show.toggle()
                                }
                            } label: {
                                Image("CloseButton")
                                    .resizable()
                                    .scaledToFit()
                            }
                            .frame(width: sc.size.width * 0.094, height: sc.size.height * 0.043)
                            .padding(.trailing, sc.size.width * 0.041)
                        }
                        .padding(.top, sc.size.height * 0.02)
                        // Dolphin Info.
                        HStack(alignment: .center){
                            Image("BotoIcon")
                                .resizable()
                                .frame(width: sc.size.width * 0.256, height: sc.size.height * 0.118)
                                .scaledToFit()
                                .padding(.leading, sc.size.width * 0.041)
                            VStack(alignment: .leading){
                                Text(Texts.DolphinName)
                                    .font(.system(size: 25, weight: .heavy, design: .rounded))
                                    .foregroundColor(Color("FontColor"))
                                    .padding(.leading, sc.size.width * 0.041)
                                Text(Texts.DolphinTitle)
                                    .font(.system(size: 19, weight: .semibold, design: .rounded))
                                    .foregroundColor(Color("FontColor"))
                                    .padding(.leading, sc.size.width * 0.041)
                            }
                        }
                        // Curupira Info.
                        HStack(alignment: .center){
                            Image("CurupiraIcon")
                                .resizable()
                                .frame(width: sc.size.width * 0.256, height: sc.size.height * 0.118)
                                .scaledToFit()
                                .padding(.leading, sc.size.width * 0.041)
                            VStack(alignment: .leading){
                                Text(Texts.CurupiraName)
                                    .font(.system(size: 25, weight: .heavy, design: .rounded))
                                    .foregroundColor(Color("FontColor"))
                                    .padding(.leading, sc.size.width * 0.041)
                                Text(Texts.CurupiraTitle)
                                    .font(.system(size: 19, weight: .semibold, design: .rounded))
                                    .foregroundColor(Color("FontColor"))
                                    .padding(.leading, sc.size.width * 0.041)
                            }
                        }
                        // Matinta Info.
                        HStack(alignment: .center){
                            Image("MatintaIcon")
                                .resizable()
                                .frame(width: sc.size.width * 0.256, height: sc.size.height * 0.118)
                                .scaledToFit()
                                .padding(.leading, sc.size.width * 0.041)
                            VStack(alignment: .leading){
                                Text(Texts.MatintaName)
                                    .font(.system(size: 25, weight: .heavy, design: .rounded))
                                    .foregroundColor(Color("FontColor"))
                                    .padding(.leading, sc.size.width * 0.041)
                                Text(Texts.MatintaTitle)
                                    .font(.system(size: 19, weight: .semibold, design: .rounded))
                                    .foregroundColor(Color("FontColor"))
                                    .padding(.leading, sc.size.width * 0.041)
                            }
                        }
                        
                        Spacer()

                    }
                }
                .ignoresSafeArea()
                .frame(width: sc.size.width, height: sc.size.height * 0.5)
            }
        }
    }
}
