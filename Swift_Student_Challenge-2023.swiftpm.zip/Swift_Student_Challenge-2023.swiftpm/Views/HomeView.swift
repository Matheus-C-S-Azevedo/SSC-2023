//
//  HomeView.swift
//  Swift_Student_Challenge-2023
//
//  Created by Matheus Costa on 13/04/23.
//

import SwiftUI

struct HomeView: View {
    
    @State private var rootPresenting: Bool = false
    
    var body: some View {
        GeometryReader{ sc in
            NavigationView {
                ZStack(alignment: .center) {
                    Image("ForestBackGround")
                        .resizable()
                        .scaledToFill()
                    VStack(alignment: .center) {
                        
                        Image("Nome")
                            .resizable()
                            .scaledToFill()
                            .frame(width: sc.size.width * 0.394, height: sc.size.height * 0.208)
                            .padding(.bottom, sc.size.height * 0.052)
                            .padding(.top, sc.size.height * 0.209)
                        
                        NavigationLink(destination: StoryView(), isActive: $rootPresenting) {
                            Image("BotaoPrincipal")
                                .resizable()
                                .scaledToFit()
                        }
                        .frame(width: sc.size.width * 0.635, height: sc.size.height * 0.109)
                        .padding(.bottom, sc.size.height * 0.298)
                    }
                }
                .ignoresSafeArea()
            }
            .navigationBarBackButtonHidden()
            .navigationBarHidden(true)
            .environment(\.rootPresentation, $rootPresenting)
        }
    }
}

struct HomeView_Previews: PreviewProvider {
    static var previews: some View {
        HomeView()
    }
}
