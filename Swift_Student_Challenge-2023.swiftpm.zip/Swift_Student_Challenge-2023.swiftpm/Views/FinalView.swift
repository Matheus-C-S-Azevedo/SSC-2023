//
//  FinalView.swift
//  Swift_Student_Challenge-2023
//
//  Created by Matheus Costa on 13/04/23.
//

import SwiftUI

struct FinalView: View {
    
    @Environment(\.rootPresentation) var rootPresentation: Binding<Bool>
    @StateObject var controller = MySingleton.instance
    
    var body: some View {
        GeometryReader{ sc in
            ZStack(alignment: .center) {
                Image("RiverBackground")
                    .resizable()
                    .scaledToFill()
                
                VStack(alignment: .center) {
                    
                    Image("CongratLbl")
                        .resizable()
                        .scaledToFill()
                        .frame(width: sc.size.width * 0.797, height: sc.size.height * 0.065)
                        .padding(.bottom, sc.size.height * 0.03)
                        .padding(.top, sc.size.height * 0.07)
                    
                    HStack(alignment: .center) {
                        
                        Image("BotoIcon")
                            .resizable()
                            .frame(width: sc.size.width * 0.256, height: sc.size.height * 0.118)
                            .scaledToFill()
                        
                        Spacer()
                        
                        Image("CurupiraIcon")
                            .resizable()
                            .frame(width: sc.size.width * 0.256, height: sc.size.height * 0.118)
                            .scaledToFill()
                        
                        Spacer()
                        
                        Image("MatintaIcon")
                            .resizable()
                            .frame(width: sc.size.width * 0.256, height: sc.size.height * 0.118)
                            .scaledToFill()
                    }
                    .padding(.horizontal, sc.size.width * 0.097)
                    .padding(.bottom, sc.size.height * 0.03)
                    
                    Text(Texts.finalText)
                        .font(.system(size: 19, weight: .regular, design: .rounded))
                        .lineSpacing(10)
                        .foregroundColor(Color("FontColor"))
                        .multilineTextAlignment(.center)
                        .padding(.horizontal, sc.size.width * 0.062)
                        .padding(.bottom, sc.size.height * 0.041)
                    
                    Spacer()
                    
                    Button {
                        rootPresentation.wrappedValue = false
                    }
                    label: {
                        Image("HomeButton")
                            .resizable()
                            .scaledToFit()
                    }
                    .frame(width: sc.size.width * 0.538, height: sc.size.height * 0.085)
                    .padding(.bottom, sc.size.height * 0.041)
                    
//                    NavigationLink(destination: StoryView()) {
//                        Image("HomeButton")
//                            .resizable()
//                            .scaledToFit()
//                    }
//                    .frame(width: sc.size.width * 0.538, height: sc.size.height * 0.085)
//                    .padding(.bottom, sc.size.height * 0.041)
                    
                }
            }
            .ignoresSafeArea()
            .navigationBarBackButtonHidden()
            .navigationBarHidden(true)
            .onAppear {
                
                controller.MonstersFinded = 0
                controller.showingBottonSheet = false
                controller.CurupiraIsEnabled = false
                controller.DolphinIsEnabled = false
                controller.MatintaIsEnabled = false
                
            }
        }
    }
}

struct FinalView_Previews: PreviewProvider {
    static var previews: some View {
        FinalView()
    }
}
