import SwiftUI
import RealityKit
import ARKit
import Combine

enum ViewType{
    case info
    case monsterInfo
}

struct ContentView : View {
    
    @StateObject var controller = MySingleton.instance
    
    var body: some View {
        GeometryReader{ sc in
            ZStack(alignment: .center){
                ARViewContainer().edgesIgnoringSafeArea(.all)
                
                // UI
                VStack(alignment: .center) {
                    
                    // Monsters Buttons.
                    HStack(alignment: .center){
                        Button {
                            if controller.DolphinIsEnabled {
                                controller.viewType = .monsterInfo
                                controller.selectedMonster = controller.DolphinInfo
                                withAnimation {
                                    controller.showingBottonSheet.toggle()
                                }
                            }
                        } label: {
                            if controller.DolphinIsEnabled {
                                Image("BotoButtonEnabled")
                                    .resizable()
                                    .scaledToFit()
                            }else{
                                Image("BotoButtonUnabled")
                                    .resizable()
                                    .scaledToFit()
                            }
                        }
                        .frame(width: sc.size.width * 0.17, height: sc.size.height * 0.08)
                        
                        Button {
                            if controller.CurupiraIsEnabled {
                                controller.viewType = .monsterInfo
                                controller.selectedMonster = controller.CurupiraInfo
                                withAnimation {
                                    controller.showingBottonSheet.toggle()
                                }
                            }
                        } label: {
                            if controller.CurupiraIsEnabled {
                                Image("CurupiraButtonEnabled")
                                    .resizable()
                                    .scaledToFit()
                            }else{
                                Image("CurupiraButtonUnabled")
                                    .resizable()
                                    .scaledToFit()
                            }
                        }
                        .frame(width: sc.size.width * 0.17, height: sc.size.height * 0.08)
                        
                        Button {
                            if controller.MatintaIsEnabled {
                                controller.viewType = .monsterInfo
                                controller.selectedMonster = controller.MatintaInfo
                                withAnimation {
                                    controller.showingBottonSheet.toggle()
                                }
                            }
                        } label: {
                            if controller.MatintaIsEnabled {
                                Image("MatintaButtonEnabled")
                                    .resizable()
                                    .scaledToFit()
                            }else{
                                Image("MatintaButtonUnabled")
                                    .resizable()
                                    .scaledToFit()
                            }                        }
                        .frame(width: sc.size.width * 0.17, height: sc.size.height * 0.08)
                        
                    }
                    .alignHorizontalCenter()
                    .padding(.top, sc.size.height * 0.07)
                    
                    Spacer()
                    
                    // Info button
                    Button {
                        controller.viewType = .info
                        withAnimation {
                            controller.showingBottonSheet.toggle()
                        }
                    } label: {
                        Image("InfoButton")
                            .resizable()
                            .scaledToFit()
                            .animation(.easeInOut(duration: 0.5).repeatForever(autoreverses: true), value: UUID())
                    }
                    .frame(width: sc.size.width * 0.17, height: sc.size.height * 0.08)
                    .padding(.bottom, sc.size.height * 0.047)
                    .padding(.trailing, sc.size.width * 0.04)
                    .alignHorizontalTrailing()
                    
                }
                
                if controller.showingBottonSheet {
                    switch controller.viewType {
                    case .info:
                        InfoView(show: $controller.showingBottonSheet)
                            .background(.black.opacity(0))
                            .transition(.move(edge: .bottom))
                    case .monsterInfo:
                        MonsterInfoView(show: $controller.showingBottonSheet, monster: controller.selectedMonster!)
                            .background(.clear)
                            .transition(.move(edge: .bottom))
                    }
                }
                
            }
            .ignoresSafeArea()
            .navigationBarBackButtonHidden()
            .navigationBarHidden(true)
            .onAppear{SoundContrller.instance.startBirdMusic()}
            .onDisappear{SoundContrller.instance.audioPlayer?.stop()}
        }
    }
}

struct ARViewContainer: UIViewRepresentable {

    func makeUIView(context: Context) -> WoldARView {

        let arView = WoldARView(frame: .zero)
        let config = ARWorldTrackingConfiguration()
        let session = arView.session
        config.planeDetection = .horizontal
        arView.session.run(config, options: [])

        // Add coaching Overlay view
        let coachingOverlay = ARCoachingOverlayView()
        coachingOverlay.autoresizingMask = [.flexibleWidth, .flexibleHeight]
        coachingOverlay.session = session
        coachingOverlay.goal = .horizontalPlane
        arView.addSubview(coachingOverlay)

        arView.setupGesture()
        arView.session.delegate = arView

        // MARK: - ADD MAIN ANCHOR
        // Create a anchora for a horizontal Plane with minimum space of 20 cmˆ2
        let mainAnchor = AnchorEntity(plane: .horizontal, minimumBounds: [0.2, 0.2])
        // Add the box anchor to the scene
        arView.scene.anchors.append(mainAnchor)

        // MARK: - ADD ENTITIES ON SCENE
        
        ///SpotLight
        let spotlight = SpotLight()
        spotlight.light.intensity = 200000
        spotlight.light.color = .white
        spotlight.light.innerAngleInDegrees = 70
        spotlight.light.outerAngleInDegrees = 120
        spotlight.light.attenuationRadius = 9.0
        spotlight.position.y = 5.0
        spotlight.shadow = SpotLightComponent.Shadow()
        spotlight.orientation = simd_quatf(angle: -.pi/1.5,
                                            axis: [1,0,0])
        mainAnchor.addChild(spotlight)
        
        ///vilage
//        let village = try! ModelEntity.loadModel(named: "Village")
//        village.position = [0,0,0]
//        village.scale = [1,1,1]
//        mainAnchor.addChild(village)
        
        var village: AnyCancellable? = nil
        village = ModelEntity.loadModelAsync(named: "Village")
            .sink(
                receiveCompletion: {error in
                    print(error)
                    village?.cancel()
                },
                receiveValue: {entity in
                    mainAnchor.addChild(entity)
                    entity.position = [0,0,0]
                    entity.scale = [1,1,1]
                    village?.cancel()
                })
        
//        let dolphin = try! ModelEntity.loadModel(named: "Dolphin")
//        dolphin.name = "Dolphin"
//        dolphin.position = [-0.127,0.029, -0.030]
//        dolphin.scale = [1,1,1]
//        dolphin.generateCollisionShapes(recursive: true)
//        mainAnchor.addChild(dolphin)
        
        var dolphin: AnyCancellable? = nil
        dolphin = ModelEntity.loadModelAsync(named: "Dolphin")
            .sink(
                receiveCompletion: {error in
                    print(error)
                    dolphin?.cancel()
                },
                receiveValue: {entity in
                    entity.name = "Dolphin"
                    entity.position = [-0.127,0.029, -0.030]
                    entity.scale = [1,1,1]
                    entity.generateCollisionShapes(recursive: true)
                    mainAnchor.addChild(entity)
                    dolphin?.cancel()
                })
        
//        let matintaPereira = try! ModelEntity.loadModel(named: "MatintaPereira")
//        matintaPereira.name = "Matinta"
//        matintaPereira.position = [0, 0.0571 , -0.01]
//        matintaPereira.scale = [1,1,1]
//        matintaPereira.generateCollisionShapes(recursive: true)
//        mainAnchor.addChild(matintaPereira)
        
        var matintaPereira: AnyCancellable? = nil
        matintaPereira = ModelEntity.loadModelAsync(named: "MatintaPereira")
            .sink(
                receiveCompletion: {error in
                    print(error)
                    matintaPereira?.cancel()
                },
                receiveValue: {entity in
                    entity.name = "Matinta"
                    entity.position = [0, 0.0571 , -0.01]
                    entity.scale = [1,1,1]
                    entity.generateCollisionShapes(recursive: true)
                    mainAnchor.addChild(entity)
                    matintaPereira?.cancel()
                })
        
//        let curupira = try! ModelEntity.loadModel(named: "Curupira")
//        curupira.name = "Curupira"
//        curupira.position = [0.100, 0.027, -0.04]
//        curupira.scale = [1,1,1]
//        curupira.generateCollisionShapes(recursive: true)
//        mainAnchor.addChild(curupira)
        
        var curupira: AnyCancellable? = nil
        curupira = ModelEntity.loadModelAsync(named: "Curupira")
            .sink(
                receiveCompletion: {error in
                    print(error)
                    curupira?.cancel()
                },
                receiveValue: {entity in
                    entity.name = "Curupira"
                    entity.position = [0.100, 0.027, -0.04]
                    entity.scale = [1,1,1]
                    entity.generateCollisionShapes(recursive: true)
                    mainAnchor.addChild(entity)
                    curupira?.cancel()
                })

        return arView
    }

    func updateUIView(_ uiView: WoldARView, context: Context) {}
}

#if DEBUG
struct ContentView_Previews : PreviewProvider {
    static var previews: some View {
        Group{
            ContentView()
                .previewDevice(PreviewDevice(rawValue: "iPhone 13 Pro Max"))
                .previewDisplayName("iPhone 13 Pro Max")
            
            ContentView()
                .previewDevice(PreviewDevice(rawValue: "iPhone SE (2nd generation)"))
                .previewDisplayName("iPhone SE (2nd generation)")
        }
    }
}
#endif
