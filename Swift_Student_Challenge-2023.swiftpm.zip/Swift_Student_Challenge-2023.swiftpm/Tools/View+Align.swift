//
//  File.swift
//  
//
//  Created by Matheus Costa on 13/04/23.
//

import Foundation
import SwiftUI


extension View {
    func alignHorizontalCenter() -> some View {
        return HStack {
            Spacer()
            self
            Spacer()
        }
    }
    
    func alignHorizontalLeading() -> some View {
        return HStack {
            self
            Spacer()
        }
    }
    
    func alignHorizontalTrailing() -> some View {
        return HStack {
            Spacer()
            self
        }
    }
    
    func alignBottom() -> some View {
        return VStack {
            Spacer()
            self
        }
    }
    
    func alignVerticalCenter() -> some View {
        return VStack {
            Spacer()
            self
            Spacer()
        }
    }
}
