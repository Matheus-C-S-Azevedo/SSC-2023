//
//  File.swift
//  
//
//  Created by Matheus Costa on 13/04/23.
//

import Foundation

extension MySingleton{
    enum Texts{
        static let DolphinDescription = "The Pink dolphin is an Amazon river's dolphin, folklore says that he turns into a tall and handsome man at night, but there is still a hole on top of his head, so he wears a hat to hide it. During the day, he helps fishermen catch fish. At night he goes to parties and makes the girls fall in love."
        
        static let CurupiraDescription = "The Curupira is a man with red hair, with feet turned backwards, he wanders through the woods leaving false footprints on the forest floor to confuse hunters, woodcutters or anyone who damages their habitat."
        
        static let MatintaDescription = "The Matinta Pereira is an old witch who turns into a bird that perches on the roofs of houses and starts to whistle, she only stops when the resident promises her something to stop (usually coffee or fish), on the next day she returns to collect the agreed bounty and gives a boon."
    }
}

class MonsterInfo {
    var labelPic: String
    var iconPic: String
    var Text: String
    
    init(labelPic: String, iconPic: String, Text: String) {
        self.labelPic = labelPic
        self.iconPic = iconPic
        self.Text = Text
    }
}

