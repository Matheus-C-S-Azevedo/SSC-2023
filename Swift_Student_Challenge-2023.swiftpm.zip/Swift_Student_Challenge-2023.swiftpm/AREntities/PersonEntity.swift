//
//  PersonEntity.swift
//  
//
//  Created by Matheus Costa on 10/04/23.
//

import Foundation
import RealityKit
import ARKit

class PersonEntity: Entity, HasModel {
    var personEntity: ModelEntity?
    
    required init() {
        super.init()
        personEntity = try! ModelEntity.loadModel(named: "Citizen")
        personEntity?.name = "Citizen"
    }
}
