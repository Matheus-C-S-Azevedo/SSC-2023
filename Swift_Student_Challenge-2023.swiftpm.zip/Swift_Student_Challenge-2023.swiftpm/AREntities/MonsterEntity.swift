//
//  EntitiesObjects.swift
//
//  Created by Matheus Costa on 08/04/23.
//

import Foundation
import RealityKit
import ARKit

class MonsterEntity: Entity, HasModel {
    var monsterEntity: ModelEntity!
    
    required init(monsterName: String) {
        super.init()
        monsterEntity = try! ModelEntity.loadModel(named: monsterName)
        monsterEntity.name = monsterName
        monsterEntity.generateCollisionShapes(recursive: true)
    }
    
    required init() {
        fatalError("init() has not been implemented")
    }
}
